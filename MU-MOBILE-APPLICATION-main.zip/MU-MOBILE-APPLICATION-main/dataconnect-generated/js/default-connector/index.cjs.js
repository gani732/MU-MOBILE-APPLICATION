
const connectorConfig = {
  connector: 'default',
  service: 'mahindra-uni-connect-mobile-main',
  location: 'us-central1'
};
exports.connectorConfig = connectorConfig;
